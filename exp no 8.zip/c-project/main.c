// Online C compiler (editor)
// Write and run C online using this editor.

#include <stdio.h>
void swap(int *a, int *b) {
    int temp; 
    temp = *a;
    *a = *b;
    *b = temp;
}
int main() {
    int num1 , num2;

    printf("Enter the first number: ");
    scanf(" %d ", &num1);
    printf("Enter the second number: ");
    scanf(" %d ", &num1);
    printf("\nBefore Swapping:\n");
    printf("first number = %d, second number = %d\n", num1 , num2);
    swap(&num1 , &num2);

    printf("After Swapping: \n");
    printf("first number = %d, second number = %d\n", num1, num2);
    return 0;
}
    
