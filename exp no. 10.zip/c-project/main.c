#include <stdio.h>

// Function to check if a year is a leap year
int isLeapYear(int year) {
    if ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0)) {
        return 1;
    }
    return 0;
}

// Function to get the starting day of the year (0 = Sun, 1 = Mon, ..., 6 = Sat)
int getFirstDayOfYear(int year) {
    int day = (year * 365 + (year - 1) / 4 - (year - 1) / 100 + (year - 1) / 400) % 7;
    return day;
}

int main() {
    int year, month, day, daysInMonth, startingDay;

    char *months[] = {
        "January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"
    };

    int monthDays[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

    printf("Enter the year: ");
    scanf("%d", &year);

    // Adjust February days if it is a leap year
    if (isLeapYear(year)) {
        monthDays[1] = 29;
    }

    // Find the first day of January for the given year
    startingDay = getFirstDayOfYear(year);

    printf("\n================ CALENDAR - %d ================\n", year);

    // Loop through all 12 months
    for (month = 0; month < 12; month++) {
        daysInMonth = monthDays[month];

        printf("\n\n  ------------ %s ------------\n", months[month]);
        printf("  Sun  Mon  Tue  Wed  Thu  Fri  Sat\n");

        // Print leading spaces for the first week
        for (int space = 0; space < startingDay; space++) {
            printf("     ");
        }

        // Print all days of the current month
        for (day = 1; day <= daysInMonth; day++) {
            printf("%5d", day);

            // Move to a new line after Saturday
            if (++startingDay > 6) {
                printf("\n");
                startingDay = 0;
            }
        }
    }
    printf("\n");

    return 0;
}
